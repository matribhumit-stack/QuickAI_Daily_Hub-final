QuickWall - Wallpaper Android App (Skeleton)
-------------------------------------------
What's included:
- Android Studio project skeleton (app module) in this folder.
- Local wallpapers inside app/src/main/assets/
- AdMob test ad integration (banner + interstitial)
- Java source files and layouts

How to build:
1. Open Android Studio -> Open an existing project -> select this folder (QuickWallApp).
2. Let Gradle sync. If prompted to update Gradle plugin or wrapper, accept recommended versions.
3. Connect an Android device or use emulator and Run the app.

Replace test AdMob IDs:
- In AndroidManifest.xml, change com.google.android.gms.ads.APPLICATION_ID meta-data to your AdMob App ID.
- In MainActivity.java, change the interstitial ad unit ID and banner ad unit ID to your real ones.
  Banner test: ca-app-pub-3940256099942544/6300978111 (already set)
  Interstitial test: ca-app-pub-3940256099942544/1033173712 (already set)
Use real IDs only after testing with test IDs to avoid invalid traffic.

Notes:
- This is a minimal skeleton meant to get you started quickly; you can add categories, more wallpapers,
  rewarded ads to unlock packs, and in-app purchases later.
- To distribute without Play Store, build signed APK (Build -> Generate Signed Bundle / APK).
- To publish to Play Store later, enroll in Google Play Console (one-time $25 fee).
