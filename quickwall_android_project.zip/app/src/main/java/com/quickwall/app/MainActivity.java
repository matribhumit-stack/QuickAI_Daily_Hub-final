package com.quickwall.app;

import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.MobileAds;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    String[] images = {"wall1.png","wall2.png","wall3.png","wall4.png","wall5.png","wall6.png"};
    private AdView adView;
    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MobileAds.initialize(this, initializationStatus -> {});

        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        gridView = findViewById(R.id.gridview);
        ImageAdapter adapter = new ImageAdapter(this, images);
        gridView.setAdapter(adapter);

        // Load interstitial (test ad unit)
        com.google.android.gms.ads.interstitial.InterstitialAd.load(this,
                "ca-app-pub-3940256099942544/1033173712",
                adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                    }
                    @Override
                    public void onAdFailedToLoad(LoadAdError adError) {
                        interstitialAd = null;
                    }
                });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String img = images[position];
                // Open fullscreen activity
                Intent i = new Intent(MainActivity.this, FullscreenActivity.class);
                i.putExtra("img", img);
                startActivity(i);
            }
        });
    }

    public void applyWallpaperFromAsset(String assetName) {
        try {
            InputStream is = getAssets().open(assetName);
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            WallpaperManager wm = WallpaperManager.getInstance(getApplicationContext());
            wm.setBitmap(bitmap);
            Toast.makeText(this, "Wallpaper Applied", Toast.LENGTH_SHORT).show();
            // show interstitial if loaded
            if (interstitialAd != null) {
                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                    @Override public void onAdDismissedFullScreenContent() {}
                    @Override public void onAdFailedToShowFullScreenContent(AdError adError) {}
                    @Override public void onAdShowedFullScreenContent() { interstitialAd = null; }
                });
                interstitialAd.show(MainActivity.this);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to apply wallpaper", Toast.LENGTH_SHORT).show();
        }
    }
}
