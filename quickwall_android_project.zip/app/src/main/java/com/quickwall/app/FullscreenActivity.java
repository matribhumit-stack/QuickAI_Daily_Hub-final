package com.quickwall.app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;

public class FullscreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        ImageView iv = findViewById(R.id.full_image);
        Button applyBtn = findViewById(R.id.apply_btn);

        String img = getIntent().getStringExtra("img"); 
        try {
            InputStream is = getAssets().open(img);
            iv.setImageBitmap(android.graphics.BitmapFactory.decodeStream(is));
        } catch (IOException e) {
            e.printStackTrace();
        }

        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    InputStream is = getAssets().open(img);
                    android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(is);
                    android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(getApplicationContext());
                    wm.setBitmap(bitmap);
                    android.widget.Toast.makeText(FullscreenActivity.this, "Wallpaper Applied", android.widget.Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
